MockStudentRepository studentRepository = new MockStudentRepository();
ManageStudentsUseCase manageStudentsUseCase = new ManageStudentsUseCase(studentRepository);
HandlerDashboardWindow dashboardPresenter = new HandlerDashboardWindow(manageStudentsUseCase);

DashboardWindow dashboardWindow = new DashboardWindow(dashboardPresenter);
dashboardPresenter.checkPermissions(authenticatedUser.getRole()); 
dashboardPresenter.loadStudents();

dashboardWindow.setVisible(true);
package src;

import domain.repository.StudentRepository;
import data.repository.MockStudentRepository;
import domain.usecase.ManageStudentsUseCase;
import presentation.dashboard.contract.DashboardPresenterContract;
import presentation.dashboard.HandlerDashboardWindow;
import presentation.dashboard.DashboardWindow;

public class App {
    public static void main(String[] args) {
        // En un escenario real, aquí inicias mostrando la LoginWindow.
        // Cuando LoginWindow valide las credenciales con éxito, llamará a un método como este:
    }

    public static void iniciarDashboardParaSesion(String userRole) {
        // 1. Instanciamos la infraestructura de datos (Capa Data)
        StudentRepository repository = new MockStudentRepository();

        // 2. Instanciamos la capa lógica inyectando el repositorio (Capa Domain)
        ManageStudentsUseCase useCase = new ManageStudentsUseCase(repository);

        // 3. Instanciamos el presentador inyectando el caso de uso (Capa Presentation)
        DashboardPresenterContract presenter = new HandlerDashboardWindow(useCase);

        // 4. Se construye la interfaz de usuario Swing inyectando el presentador y el Rol verificado
        java.awt.EventQueue.invokeLater(() -> {
            DashboardWindow dashboard = new DashboardWindow(presenter, userRole);
            dashboard.setVisible(true);
        });
    }
}